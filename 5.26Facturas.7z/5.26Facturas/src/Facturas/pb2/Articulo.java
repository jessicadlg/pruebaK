package Facturas.pb2;

public class Articulo {
	private String descripcion;
	private Double precio;
	
	
	public Articulo(String descripcion, Double precio) {
		this.descripcion = descripcion;
		this.precio = precio;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	
	public Double obtenerImpuesto() {
		return 0.21 * this.getPrecio();
	}
	public Integer getPrecioFinal() {
		
		return null;
	}
}
