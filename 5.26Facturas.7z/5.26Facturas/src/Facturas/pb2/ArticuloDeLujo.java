package Facturas.pb2;

public class ArticuloDeLujo extends Articulo {

	public ArticuloDeLujo(String descripcion, Double precio) {
		super(descripcion, precio);
	}
	
	@Override
	public Double obtenerImpuesto() {
		return super.obtenerImpuesto() + 0.15 * this.getPrecio();
	}
//	agregado p ejemplaificar (este triplico refiere al metodo de arriba porq no
//	puede acceder al de la clase articulo porq esta encapsulado)
	public Double triplicoImpuesto() {
		return this.obtenerImpuesto();
		
	}
}
