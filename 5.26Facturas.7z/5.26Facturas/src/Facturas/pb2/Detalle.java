package Facturas.pb2;

public class Detalle {
	private Articulo articulo;
	private Integer cantidad;
	
	public Detalle(Articulo articulo, Integer cantidad) {
		this.articulo = articulo;
		this.cantidad = cantidad;
	}

	public Articulo getArticulo() {
		return articulo;
	}
	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	
	public Double getPrecioTotal() {
	return  (double) (this.getArticulo().getPrecioFinal() * this.getCantidad());
	}
		
}
	


