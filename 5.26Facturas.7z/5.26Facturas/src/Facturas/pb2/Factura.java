package Facturas.pb2;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Factura {
	private List<Detalle> detalles = new LinkedList<>();

	public void addDetalle(Detalle detalle) {
		this.detalles.add(detalle);
	}
	
	public List <Detalle> getDetalles(){
		return Collections.unmodifiableList(this.detalles);
	}
	public Double getPrecioTotal() {
		Double total=0.0;
		return total;
	}
			
}
