package Facturas.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArticuloTest {

	@Test
	public void testQueSePuedaPedirImpuestosSobreArticulo() {
		Articulo a1= new Articulo("Pescado",10.0);
		assertEquals("El impuesto es normal", 2.1,a1.obtenerImpuesto(),0.0);
	}
	@Test
	public void testQueSePuedaPedirImpuestosSobreArticuloDeLujo() {
		Articulo a1= new ArticuloDeLujo("Perfume",10.0);
		assertEquals("El impuesto es extraordinario", 3.6,a1.obtenerImpuesto(),0.0);
	}
	
	
	
	

}
