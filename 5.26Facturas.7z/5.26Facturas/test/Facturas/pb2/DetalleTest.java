package Facturas.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class DetalleTest {

	@Test
	public void testQueSePuedaCalcularElTotalPorDetalle() {
	Articulo articulo = new Articulo("pescado",10.0);
	Detalle d1= new Detalle(articulo, 2); 
	assertEquals("El precio total con impuesto", 24.2,d1.getPrecioTotal(),0.0);
	}

}
